= Compile project =

$ mkdir build

$ cd build

$ cmake ..

$ make -j 8