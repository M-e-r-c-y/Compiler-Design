/* simple program */

extern int f;

void function(int x, int y)
{
    int f;

    while (x < y)
    {
        f++;
        x++;
    }
}

int main(void)
{
    printf("Hello world\n");

    return 0;
}
